"""
Machine Learning-Based Network Intrusion Detector
Educational prototype using synthetic data; not for production security decisions.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, ConfusionMatrixDisplay
)

def make_demo_data(n=2500, random_state=42):
    """Create synthetic flow-like features for a reproducible demonstration."""
    rng = np.random.default_rng(random_state)
    suspicious = rng.binomial(1, 0.35, n)
    duration = rng.gamma(shape=2.0 + suspicious * 0.8, scale=1.5, size=n)
    bytes_out = rng.lognormal(mean=7.0 + suspicious * 0.9, sigma=0.8, size=n)
    bytes_in = rng.lognormal(mean=7.2 - suspicious * 0.35, sigma=0.9, size=n)
    packet_count = rng.poisson(lam=18 + suspicious * 22, size=n) + 1
    failed_connections = rng.poisson(lam=0.4 + suspicious * 3.0, size=n)
    unique_ports = np.clip(rng.poisson(lam=2 + suspicious * 8, size=n), 1, 30)
    protocol_code = rng.choice([0, 1, 2], size=n, p=[0.55, 0.35, 0.10])
    df = pd.DataFrame({
        "duration_seconds": duration,
        "bytes_out": bytes_out,
        "bytes_in": bytes_in,
        "packet_count": packet_count,
        "failed_connections": failed_connections,
        "unique_destination_ports": unique_ports,
        "protocol_code": protocol_code,
        "label": suspicious
    })
    return df

def main():
    df = make_demo_data()
    X = df.drop(columns="label")
    y = df["label"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = RandomForestClassifier(
        n_estimators=150, random_state=42, class_weight="balanced"
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print("EDUCATIONAL DEMO — synthetic data only")
    print(f"Test records: {len(y_test)}")
    print(f"Accuracy:  {accuracy_score(y_test, predictions):.3f}")
    print(f"Precision: {precision_score(y_test, predictions, zero_division=0):.3f}")
    print(f"Recall:    {recall_score(y_test, predictions, zero_division=0):.3f}")
    print(f"F1-score:  {f1_score(y_test, predictions, zero_division=0):.3f}")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, target_names=["Normal", "Suspicious"], zero_division=0))

    ConfusionMatrixDisplay.from_predictions(
        y_test, predictions, display_labels=["Normal", "Suspicious"], cmap="Blues"
    )
    plt.title("Confusion Matrix — Synthetic Demonstration")
    plt.tight_layout()
    plt.show()

    importances = pd.Series(model.feature_importances_, index=X.columns).sort_values()
    importances.plot(kind="barh", title="Feature Importance — Synthetic Demonstration")
    plt.xlabel("Importance")
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
